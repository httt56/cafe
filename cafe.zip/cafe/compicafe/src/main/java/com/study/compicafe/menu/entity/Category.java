package com.study.compicafe.menu.entity;

public class Category {

}
