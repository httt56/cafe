package com.study.compicafe.menu.repository;

public interface CategoryRepository {


}
