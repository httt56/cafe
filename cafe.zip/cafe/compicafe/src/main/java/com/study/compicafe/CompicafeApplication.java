package com.study.compicafe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompicafeApplication {

    public static void main(String[] args) {
        SpringApplication.run(CompicafeApplication.class, args);
    }

}
